<?php
    class Class_Echo {
        /**
         * @remotable
         */
    	public function send($string){
    		return $string;
    	}
    }
?>
